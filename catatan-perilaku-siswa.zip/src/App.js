import { useState } from "react";

function App() {
  const [siswa, setSiswa] = useState("");
  const [kelas, setKelas] = useState("");
  const [perilaku, setPerilaku] = useState("");
  const [catatan, setCatatan] = useState([]);

  const tambahCatatan = () => {
    if (!siswa || !kelas || !perilaku) return;
    setCatatan([
      ...catatan,
      {
        id: Date.now(),
        nama: siswa,
        kelas,
        perilaku,
        tanggal: new Date().toLocaleDateString(),
      },
    ]);
    setSiswa("");
    setKelas("");
    setPerilaku("");
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Catatan Perilaku Siswa</h1>
      <input placeholder="Nama Siswa" value={siswa} onChange={(e) => setSiswa(e.target.value)} /><br />
      <input placeholder="Kelas" value={kelas} onChange={(e) => setKelas(e.target.value)} /><br />
      <textarea placeholder="Catatan Perilaku" value={perilaku} onChange={(e) => setPerilaku(e.target.value)} /><br />
      <button onClick={tambahCatatan}>Tambah Catatan</button>

      <ul>
        {catatan.map((item) => (
          <li key={item.id}>
            <strong>{item.nama}</strong> ({item.kelas}) - {item.perilaku} [{item.tanggal}]
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
